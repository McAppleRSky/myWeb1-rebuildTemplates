package ru.krt.copypast.hamlscript.pojo;

public class FileList {
    private String haml;
    private String html;

    public String getHaml() {
        return haml;
    }

    public void setHaml(String haml) {
        this.haml = haml;
    }

    public String getHtml() {
        return html;
    }

    public void setHtml(String html) {
        this.html = html;
    }

    public FileList(String haml, String html) {
        this.haml = haml;
        this.html = html;
    }

    public FileList() {
    }
}